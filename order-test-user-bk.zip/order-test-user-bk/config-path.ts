export const PATH_USER_DOMAIN = 'src/user/domain';
export const PATH_USER_APPLICATION = 'src/user/application';
export const PATH_USER_INFRASTRUCTURE = 'src/user/infrastructure';
export const PATH_USER_TEST = 'test/user/';

export const SNAP_PATH_USER_DOMAIN = '/user/domain';
export const SNAP_PATH_USER_APPLICATION = '/user/application';
export const SNAP_PATH_USER_INFRASTRUCTURE = '/user/infrastructure';
export const SNAP_PATH_USER_TEST = '/user/test';
