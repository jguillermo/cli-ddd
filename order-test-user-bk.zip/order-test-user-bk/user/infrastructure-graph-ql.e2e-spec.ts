import { cleanRender, DDD, menu, MenuPropertie, readRender, readSnapShot, run } from '../load-cmd';
import { PATH_USER_INFRASTRUCTURE, PATH_USER_TEST, SNAP_PATH_USER_INFRASTRUCTURE, SNAP_PATH_USER_TEST } from '../config-path';

const MENU = menu(MenuPropertie.USER, DDD.INFRASTRUCTURE_GRAPH_QL);
describe('User infrastructure GraphQL', () => {
  beforeEach(() => {
    cleanRender();
  });
  test('generate App GraphQL User', async () => {
    await run([...MENU]);
    const renderAggregate = readRender(PATH_USER_INFRASTRUCTURE + '/graph-ql/user.type.ts');
    const renderResolver = readRender(PATH_USER_INFRASTRUCTURE + '/graph-ql/user.resolver.ts');

    const snapAggregate = readSnapShot(SNAP_PATH_USER_INFRASTRUCTURE + '/graph-ql/type.txt');
    const snapResolver = readSnapShot(SNAP_PATH_USER_INFRASTRUCTURE + '/graph-ql/resolver.txt');
    expect(renderAggregate).toEqual(snapAggregate);
    expect(renderResolver).toEqual(snapResolver);
  });
  describe('generate App GraphQL User test', () => {
    test('delete', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/graph-ql/user-delete.e2e-spec.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/graph-ql/delete.txt');
      expect(render).toEqual(snap);
    });

    test('findById', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/graph-ql/user-find-by-id.e2e-spec.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/graph-ql/find-by-id.txt');
      expect(render).toEqual(snap);
    });

    test('list', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/graph-ql/user-list.e2e-spec.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/graph-ql/list.txt');
      expect(render).toEqual(snap);
    });

    test('persist', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/graph-ql/user-persist.e2e-spec.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/graph-ql/persist.txt');
      expect(render).toEqual(snap);
    });

    test('e2e module', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/graph-ql/user-e2e-module.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/graph-ql/e2e-module.txt');
      expect(render).toEqual(snap);
    });

    test('object Mother', async () => {
      await run([...MENU]);
      const render = readRender(PATH_USER_TEST + '/user-object-mother.ts');
      const snap = readSnapShot(SNAP_PATH_USER_TEST + '/object-mother.txt');
      expect(render).toEqual(snap);
    });
  });
});
