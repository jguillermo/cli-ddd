import { cleanRender, copyfromSnapToRender, DDD, ENTER, menu, MenuPropertie, readRender, readSnapShot, run } from '../load-cmd';
import { PATH_USER_INFRASTRUCTURE, SNAP_PATH_USER_INFRASTRUCTURE } from '../config-path';

const MENU = menu(MenuPropertie.USER, DDD.INFRASTRUCTURE_EVENT);
describe('User infrastructure event', () => {
  beforeEach(() => {
    cleanRender();
  });
  test.skip('no existe event', async () => {
    const result = await run([...MENU]);
    expect(result).toMatch(/No exist Events/);
  });
  test('event created', async () => {
    copyfromSnapToRender(SNAP_PATH_USER_INFRASTRUCTURE + '/event/resource-on-user-created.txt', 'src/user/domain/user-created.event.ts');
    await run([...MENU, ENTER, ENTER]);
    const renderAggregate = readRender(PATH_USER_INFRASTRUCTURE + '/event/resource-on-user-created.ts');
    const snapAggregate = readSnapShot(SNAP_PATH_USER_INFRASTRUCTURE + '/event/resource-on-user-created.txt');

    expect(renderAggregate).toEqual(snapAggregate);

    const renderIndex = readRender(PATH_USER_INFRASTRUCTURE + '/event/index.ts');
    const snapIndex = readSnapShot(SNAP_PATH_USER_INFRASTRUCTURE + '/event/index/one-event.txt');
    expect(renderIndex).toEqual(snapIndex);
  });
});
